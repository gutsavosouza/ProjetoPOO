package transporte;

public interface Transporte {
    
    public void transportar(String LocalAtual);
}
