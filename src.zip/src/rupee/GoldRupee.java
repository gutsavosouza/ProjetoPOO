package rupee;

public class GoldRupee extends Rupee{
    
    public GoldRupee() {
        super(300);
    }
    
}
