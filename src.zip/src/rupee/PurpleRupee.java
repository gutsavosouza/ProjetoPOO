package rupee;

public class PurpleRupee extends Rupee{
    
    public PurpleRupee() {
        super(50);
    }
    
}
