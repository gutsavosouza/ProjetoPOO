package rupee;


public class BlueRupee extends Rupee{
    
    public BlueRupee() {
        super(5);
    }
    
}
