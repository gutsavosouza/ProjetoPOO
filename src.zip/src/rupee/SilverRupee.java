package rupee;

public class SilverRupee extends Rupee{
    
    public SilverRupee() {
        super(100);
    }
    
}
