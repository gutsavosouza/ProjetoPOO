package rupee;


public class RedRupee extends Rupee{
    
    public RedRupee() {
        super(10);
    }
    
}
