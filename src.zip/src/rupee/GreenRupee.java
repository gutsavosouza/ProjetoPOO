package rupee;


public class GreenRupee extends Rupee{
    
    public GreenRupee() {
        super(1);
    }
    
}
