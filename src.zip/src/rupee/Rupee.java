package rupee;


public class Rupee {
    
    private int valor;

    public Rupee(int valor) {
        this.valor = valor;
    }
    
    public int getValor() {
        return valor;
    }
    
}
