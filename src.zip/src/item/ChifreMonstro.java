package item;

public class ChifreMonstro extends Item{
    
    public ChifreMonstro() {
        super("Chifre de Monstro" , "Nenhum", 0, 0);
    }
    
}
