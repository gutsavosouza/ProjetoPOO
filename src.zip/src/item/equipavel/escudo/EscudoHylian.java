package item.equipavel.escudo;

public class EscudoHylian extends Escudo {

    public EscudoHylian() {
        super("Escudo de Hylian", 0, 0, 2);
    }
}
