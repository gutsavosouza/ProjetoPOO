package item.equipavel.escudo;

public class EscudoMadeira extends Escudo{

    public EscudoMadeira() {
        super("Escudo de madeira", 50, 0, 1);
    }
}
