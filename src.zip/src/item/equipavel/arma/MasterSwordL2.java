package item.equipavel.arma;

public class MasterSwordL2 extends MasterSword {

    public MasterSwordL2() {
        super("Master Sword Lv.2", 8);
    }
}
