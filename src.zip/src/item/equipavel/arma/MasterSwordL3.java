package item.equipavel.arma;

public class MasterSwordL3 extends MasterSword {

    public MasterSwordL3() {
        super("Master Sword Lv.3", 16);
    }
}
