package item.equipavel.arma;

public class MasterSwordL1 extends MasterSword {

    public MasterSwordL1() {
        super("Master Sword", 4);
    }  
}