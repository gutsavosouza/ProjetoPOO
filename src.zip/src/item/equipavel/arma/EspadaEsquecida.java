package item.equipavel.arma;

public class EspadaEsquecida extends Espada{

    public EspadaEsquecida() {
        super("Espada esquecida", 2);
    }
}
