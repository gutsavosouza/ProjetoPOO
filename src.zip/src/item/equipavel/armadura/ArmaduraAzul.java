package item.equipavel.armadura;

public class ArmaduraAzul extends Armadura {

    public ArmaduraAzul() {
        super("Armadura azul", 0, 0, 3);
    }
}
