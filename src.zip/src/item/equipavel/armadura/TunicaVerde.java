package item.equipavel.armadura;

public class TunicaVerde extends Armadura{

    public TunicaVerde() {
        super("Túnica verde", 0, 0, 1);
    }
}
