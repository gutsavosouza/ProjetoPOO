package item.equipavel.armadura;

public class ArmaduraVermelha extends Armadura{

    public ArmaduraVermelha() {
        super("Armadura vermleha", 0, 0, 2);
    }
}
