package item;

public class EstomagoMonstro extends Item{
    
    public EstomagoMonstro() {
        super("Estomago de Monstro", "Nenhum", 0, 0);
    }
    
}
