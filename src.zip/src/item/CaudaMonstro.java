package item;

public class CaudaMonstro extends Item{
    
    public CaudaMonstro() {
        super("Cauda de Monstro" , "Nenhum", 0, 0);
    }
    
}
