package item;

public class SemItem extends Item {

    public SemItem() {
        super("Sem Item", "Inválido", 0, 0);
    }
}
