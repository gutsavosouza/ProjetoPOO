package npc.animal.galinha;

public class GalinhaDourada extends Galinha {

    public GalinhaDourada() {
        super(50, "Dourada");
    }
}
