package npc.monstro;

import ataque.monstro.MoblinAtaque;
import ataque.monstro.MonstroAtaque;

public class Moblin extends Monstro {

    public Moblin() {
        super(10, "Moblin","Comum", new MoblinAtaque());
    }
    
}
