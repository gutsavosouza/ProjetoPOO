package npc.monstro;

import ataque.monstro.HinoxAtaque;

public class Hinox extends Monstro {
    
    public Hinox() {
        super(28, "Hinox","Comum", new HinoxAtaque());
    }
    
}
