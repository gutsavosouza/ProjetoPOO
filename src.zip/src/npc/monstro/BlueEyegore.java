
package npc.monstro;

import ataque.monstro.BlueEyegoreAtaque;
import ataque.monstro.MonstroAtaque;

public class BlueEyegore extends Monstro {

    public BlueEyegore() {
        super(14, "Blue Eyegore","Comum", new BlueEyegoreAtaque());
    }
    
}
