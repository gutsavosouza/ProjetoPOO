package npc.monstro;

import ataque.monstro.BawbAtaque;

public class Bawb extends Monstro {

    public Bawb() {
        super(2, "Bawb","Comum", new BawbAtaque());
    }
}
