package npc.monstro;

import ataque.monstro.DeadrockAtaque;

public class Deadrock extends Monstro {

    public Deadrock() {
        super(6, "Deadrock","Comum", new DeadrockAtaque());
    } 
}
