package ataque.monstro;

public class BawbAtaque extends MonstroAtaque {

    public BawbAtaque() {
        super(4);
    }
}
