package ataque.monstro;

public class DeadrockAtaque extends MonstroAtaque {

    public DeadrockAtaque() {
        super(8);
    }
}
