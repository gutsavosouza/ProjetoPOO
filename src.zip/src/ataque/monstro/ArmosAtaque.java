package ataque.monstro;

public class ArmosAtaque extends MonstroAtaque {

    public ArmosAtaque() {
        super(4);
    }
}
