package ataque.monstro;

public class LynelAtaque extends MonstroAtaque{

    public LynelAtaque() {
        super(6);
    }
    
}
