package ataque.monstro;

public class LeeverAtaque extends MonstroAtaque{
    
    public LeeverAtaque() {
        super(4);
    }
    
}
