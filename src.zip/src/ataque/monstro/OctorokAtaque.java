package ataque.monstro;

public class OctorokAtaque extends MonstroAtaque{

    public OctorokAtaque() {
        super(2);
    }
    
}
