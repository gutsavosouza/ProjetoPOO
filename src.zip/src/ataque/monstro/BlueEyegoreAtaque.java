
package ataque.monstro;

public class BlueEyegoreAtaque extends MonstroAtaque{

    public BlueEyegoreAtaque() {
        super(4);
    }
    
}
