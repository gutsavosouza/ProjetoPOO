package ataque.monstro;

public class LoruleSoliderAtaque extends MonstroAtaque{

    public LoruleSoliderAtaque() {
        super(6);
    }
    
}
