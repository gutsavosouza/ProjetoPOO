package ataque.monstro;

public class RedKodongoAtaque extends MonstroAtaque{
    
    public RedKodongoAtaque() {
        super(6);
    }
    
}
