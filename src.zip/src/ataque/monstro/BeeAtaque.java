package ataque.monstro;

public class BeeAtaque extends MonstroAtaque {

    public BeeAtaque() {
        super(3);
    }
}
