package ataque.monstro;

public class MoblinAtaque extends MonstroAtaque{

    public MoblinAtaque() {
        super(2);
    }
    
}
