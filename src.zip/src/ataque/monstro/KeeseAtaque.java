package ataque.monstro;

public class KeeseAtaque extends MonstroAtaque{
    
    public KeeseAtaque() {
        super(2);
    }
    
}
