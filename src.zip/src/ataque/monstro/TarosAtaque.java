package ataque.monstro;

public class TarosAtaque extends MonstroAtaque{

    public TarosAtaque() {
        super(4);
    }
    
}
