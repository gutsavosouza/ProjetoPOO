package ataque.monstro;

public class IceWizzrobeAtaque extends MonstroAtaque{
    
    public IceWizzrobeAtaque() {
        super(4);
    }
    
}
