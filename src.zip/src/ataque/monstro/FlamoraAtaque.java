package ataque.monstro;

public class FlamoraAtaque extends MonstroAtaque{
    
    public FlamoraAtaque() {
        super(6);
    }
    
}
