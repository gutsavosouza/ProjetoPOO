package ataque.monstro;

public class HinoxAtaque extends MonstroAtaque{
    
    public HinoxAtaque() {
        super(4);
    }
    
}
