package ataque.monstro;

public class RopaAtaque extends MonstroAtaque{

    public RopaAtaque() {
        super(6);
    }
    
}
