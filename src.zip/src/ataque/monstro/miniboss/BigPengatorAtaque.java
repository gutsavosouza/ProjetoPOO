package ataque.monstro.miniboss;

import ataque.monstro.MonstroAtaque;

public class BigPengatorAtaque extends MonstroAtaque{
    
    public BigPengatorAtaque() {
        super(8);
    }
    
}
