package ataque.monstro.miniboss;

import ataque.monstro.MonstroAtaque;

public class ArrghusAtaque extends MonstroAtaque{
    
    public ArrghusAtaque() {
        super(4);
    }
    
}
