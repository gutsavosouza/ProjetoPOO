package ataque.monstro.miniboss;

import ataque.monstro.MonstroAtaque;

public class RedStalfosAtaque extends MonstroAtaque{
    
    public RedStalfosAtaque() {
        super(2);
    }
    
}
