package ataque.monstro.miniboss;

import ataque.monstro.MonstroAtaque;

public class GigabariAtaque extends MonstroAtaque{
    
    public GigabariAtaque() {
        super(4);
    }
    
}
