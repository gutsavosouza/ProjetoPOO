package ataque.monstro.miniboss;

import ataque.monstro.MonstroAtaque;

public class LoruleBallAtaque extends MonstroAtaque{
    
    public LoruleBallAtaque() {
        super(8);
    }
    
}
