package ataque.monstro.miniboss;

import ataque.monstro.MonstroAtaque;

public class HeedleAtaque extends MonstroAtaque{
    
    public HeedleAtaque() {
        super(4);
    }
    
}
