package ataque.monstro;

public class DarkGhiniAtaque extends MonstroAtaque{
    
    public DarkGhiniAtaque() {
        super(4);
    }
    
}
