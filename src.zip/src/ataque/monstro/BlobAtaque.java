package ataque.monstro;

public class BlobAtaque extends MonstroAtaque {

    public BlobAtaque() {
        super(2);
    }
}
