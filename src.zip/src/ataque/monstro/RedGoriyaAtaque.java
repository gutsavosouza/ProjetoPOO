package ataque.monstro;

public class RedGoriyaAtaque extends MonstroAtaque{
    
    public RedGoriyaAtaque( ) {
        super(8);
    }
    
}
