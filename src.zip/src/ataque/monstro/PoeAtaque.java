package ataque.monstro;

public class PoeAtaque extends MonstroAtaque{

    public PoeAtaque() {
        super(2);
    }
    
}
