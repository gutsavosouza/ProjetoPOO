package ataque.monstro;

public class BlueSwordSoldierAtaque extends MonstroAtaque{

    public BlueSwordSoldierAtaque() {
        super(2);
    }
    
}
