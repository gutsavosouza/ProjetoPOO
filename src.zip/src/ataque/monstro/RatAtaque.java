package ataque.monstro;

public class RatAtaque extends MonstroAtaque {

    public RatAtaque() {
        super(4);
    }
}
