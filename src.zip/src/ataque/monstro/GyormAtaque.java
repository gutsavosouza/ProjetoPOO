package ataque.monstro;

public class GyormAtaque extends MonstroAtaque{
    
    public GyormAtaque() {
        super(4);
    }
    
}
