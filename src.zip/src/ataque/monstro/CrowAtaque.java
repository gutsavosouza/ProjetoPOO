package ataque.monstro;

public class CrowAtaque extends MonstroAtaque {

    public CrowAtaque() {
        super(3);
    }
}
