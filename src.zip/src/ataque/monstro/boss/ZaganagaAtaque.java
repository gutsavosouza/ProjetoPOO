package ataque.monstro.boss;

import ataque.monstro.MonstroAtaque;

public class ZaganagaAtaque extends MonstroAtaque{
    
    public ZaganagaAtaque() {
        super(8);
    }
    
}
