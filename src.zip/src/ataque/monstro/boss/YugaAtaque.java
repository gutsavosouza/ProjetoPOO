package ataque.monstro.boss;

import ataque.monstro.MonstroAtaque;

public class YugaAtaque extends MonstroAtaque{
    
    public YugaAtaque() {
        super(4);
    }
    
}
