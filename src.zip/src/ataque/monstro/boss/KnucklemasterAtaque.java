package ataque.monstro.boss;

import ataque.monstro.MonstroAtaque;

public class KnucklemasterAtaque extends MonstroAtaque{
    
    public KnucklemasterAtaque() {
        super(8);
    }
    
}
