package ataque.monstro.boss;

import ataque.monstro.MonstroAtaque;

public class MoldormAtaque extends MonstroAtaque{
    
    public MoldormAtaque() {
        super(4);
    }
    
}
