package ataque.monstro.boss;

import ataque.monstro.MonstroAtaque;

public class YugaGanonAtaque extends MonstroAtaque{
    
    public YugaGanonAtaque() {
        super(14);
    }
    
}
