package ataque.monstro.boss;

import ataque.monstro.MonstroAtaque;

public class MargomillAtaque extends MonstroAtaque{
    
    public MargomillAtaque() {
        super(4);
    }
    
}
