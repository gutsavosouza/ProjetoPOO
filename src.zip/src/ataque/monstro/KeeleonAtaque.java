package ataque.Monstro;

import ataque.monstro.MonstroAtaque;

public class KeeleonAtaque extends MonstroAtaque{
    
    public KeeleonAtaque() {
        super(6);
    }
    
}
