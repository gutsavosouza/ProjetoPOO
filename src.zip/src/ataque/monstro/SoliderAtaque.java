package ataque.monstro;

public class SoliderAtaque extends MonstroAtaque{

    public SoliderAtaque() {
        super(4);
    }
    
}
