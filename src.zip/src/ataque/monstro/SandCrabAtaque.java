package ataque.monstro;

public class SandCrabAtaque extends MonstroAtaque{

    public SandCrabAtaque() {
        super(2);
    }
    
}
